class patient:
    def __init__(self,patientid,firstname,lastname,dateofbirth,gender,contactnumber,address):
        self.patientid=patientid
        self.firstname = firstname
        self.lastname = lastname
        self.dateofbirth = dateofbirth
        self.gender = gender
        self.contactnumber = contactnumber
        self.address = address

    @property
    def getpatientid(self):
        return self.patientid

    @property
    def getfirstname(self):
        return self.firstname

    @property
    def getlastname(self):
        return self.lastname

    @property
    def getdateofbirth(self):
        return self.dateofbirth

    @property
    def getgender(self):
        return self.gender

    @property
    def getcontactnumber(self):
        return self.contactnumber

    @property
    def getaddress(self):
        return self.address
    @getpatientid.setter
    def setpatientid(self,patientid):
        self.patientid=patientid
    @getfirstname.setter
    def setfirstname(self,firstname):
        self.firstname=firstname
    @getlastname.setter
    def setlastname(self,lastname):
        self.lastname=lastname
    @getdateofbirth.setter
    def setdateofbirth(self,dateofbirth):
        self.dateofbirth=dateofbirth
    @getgender.setter
    def setgender(self,gender):
        self.gender=gender
    @getcontactnumber.setter
    def setcontactnumber(self,contactnumber):
        self.contactnumber=contactnumber
    @getaddress.setter
    def setaddress(self,address):
        self.address=address


class doctor:
    def __init__(self,doctorid,firstname,lastname,specialization,contactnumber):
        self.doctorid = doctorid
        self.firstname = firstname
        self.lastname = lastname
        self.specialization = specialization
        self.contactnumber = contactnumber

    @property
    def getdoctortid(self):
        return self.doctorid
    @property
    def getfirstname(self):
        return self.firstname
    @property
    def getlastname(self):
        return self.lastname
    @property
    def getspecialization(self):
        return self.specialization
    @property
    def getcontactnumber(self):
        return self.contactnumber

    @getdoctortid.setter
    def setpatientid(self, doctorid):
        self.doctorid = doctorid
    @getfirstname.setter
    def setfirstname(self, firstname):
        self.firstname = firstname
    @getlastname.setter
    def setlastname(self, lastname):
        self.lastname = lastname
    @getspecialization.setter
    def setspecialization(self, specialization):
        self.specialization = specialization
    @getcontactnumber.setter
    def setcontactnumber(self, contactnumber):
        self.contactnumber = contactnumber

class appointment:
    def __init__(self,appointmentid,patientid,doctorid,appointmentdate,description):
        self.appointmentid = appointmentid
        self.patientid = patientid
        self.doctorid = doctorid
        self.appointmentdate = appointmentdate
        self.description = description

    @property
    def getappointmentid(self):
        return self.appointmentid
    @property
    def getpatientid(self):
        return self.patientid
    @property
    def getdoctortid(self):
        return self.doctorid
    @property
    def getappointmentdate(self):
        return self.appointmentdate
    @property
    def getdescription(self):
        return self.description

    @getappointmentid.setter
    def setappointmentid(self,appointmentid):
        self.appointmentid=appointmentid
    @getpatientid.setter
    def setpatientid(self,patientid):
        self.patientid=patientid
    @getdoctortid.setter
    def setpatientid(self, doctorid):
        self.doctorid = doctorid
    @getappointmentdate.setter
    def setappointmentdate(self,appointmentdate):
        self.appointmentdate=appointmentdate
    @getdescription.setter
    def setdescription(self,description):
        self.description=description


