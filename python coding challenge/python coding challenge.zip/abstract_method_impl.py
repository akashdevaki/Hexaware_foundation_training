import random
class patientnotfoundException:
    pass
import mysql.connector
from mysql.connector import Error
con=mysql.connector.connect(host="localhost",
                            user="root",
                            password="root",
                            port="3306",
                            database="hospital")
cur=con.cursor()

from abc import ABC,abstractmethod
class ihospitalservice(ABC):
    def getAppointmentById(self,appointmentid):
        pass
    def getAppointmentsForPatient(self,patientid):
        pass
    def getAppointmentsForDoctor(self,doctorid):
        pass
    def scheduleAppointment(self):
        pass
    def updateAppointment(self,appointmentid):
        pass
    def cancelAppointment(self,appointid):
        pass



class ihospitalserviceimpl(ihospitalservice):
    def getAppointmentById(self,appointmentid):
        query="select * from appointment where appointmentid=%s"
        cur.execute(query,(appointmentid,))
        output=cur.fetchall()
        for i in output:
            print(i)

    def getAppointmentsForPatient(self, patientid):
        try:
            query = "select * from appointment where patientid=%s"
            cur.execute(query, (patientid,))
            output = cur.fetchall()
            if not output:
                print(f"Error:invalid patientid {patientid}")
            for i in output:
                print(i)
        finally:
            con.commit()


    def getAppointmentsForDoctor(self, doctorid):
        query = "select * from appointment where doctorid=%s"
        cur.execute(query, (doctorid,))
        output = cur.fetchall()
        for i in output:
            print(i)

    def all_patients(self):
        query="select * from patient"
        cur.execute(query)
        return cur.fetchall()
    def get_unique_patientid(self):
        return len(self.all_patients())+1
    def all_appointments(self):
        query="select * from appointment"
        cur.execute(query)
        return cur.fetchall()
    def get_unique_appointmentid(self):
        return len(self.all_appointments())+1
    def all_doctors(self):
        query="select * from doctor"
        cur.execute(query)
        output=cur.fetchall()
        for i in output:
            print(i)
    def create_patient(self):
        patientid = self.get_unique_patientid()
        firstname = input("enter the first name")
        lastname = input("enter the last name")
        dateofbirth = input("enter the dateofbirth")
        gender= input("enter the gender")
        contactnumber = input("enter the contactnumber")
        address = input("enter the address")

        ca = {
            'patientid': patientid,
            'firstname': firstname,
            'lastname': lastname,
            'dateofbirth': dateofbirth,
            'gender': gender,
            'contactnumber': contactnumber,
            'address': address,
        }
        query = "insert into patient values(%s,%s,%s,%s,%s,%s,%s)"
        values = (ca['patientid'], ca['firstname'], ca['lastname'], ca['dateofbirth'], ca['gender'],
                  ca['contactnumber'],ca['address'])
        cur.execute(query, values)
        cur.fetchall()
        con.commit()

    def scheduleAppointment(self):
        appointmentid=self.get_unique_appointmentid()
        patientid=self.get_unique_patientid()
        docterid=random.randint(1,3)
        appointmentdate=input("enter the appointment date")
        description=input("enter the reason")
        sa={
            'appointmentid':appointmentid,
            'patientid':patientid,
            'doctorid':docterid,
            'appointmentdate':appointmentdate,
            'description':description
        }
        query="insert into appointment values(%s,%s,%s,%s,%s)"
        values=(sa['appointmentid'],sa['patientid'],sa['doctorid'],sa['appointmentdate'],sa['description'])
        cur.execute(query,values)
        self.create_patient()
        output=cur.fetchall()
        con.commit()
        for i in output:
            print(i)

    def updateAppointment(self,appointmentid):

        try:
            '''query="select * from appointment where appointmentid=%s"
            cur.execute(query)
            output=cur.fetchall()
            if not output:
                print(f"Error: artwork {appointmentid} not found")'''

            print("select the below options to update:")
            print("1.doctorid")
            print("2.description")
            print("3.appointmentdate")

            choice = input("enter the option you want to change: ")
            if choice == "1":
                self.all_doctors()
                doctorid = input("enter the doctorid: ")
                query = "update appointment set doctorid=%s where appointmentid= %s"
                cur.execute(query, (doctorid,appointmentid,))
                cur.fetchone()
                con.commit()

            elif choice == "2":
                description = input("enter the description: ")
                query = "update appointment set description=%s where appointmentid= %s"
                cur.execute(query, (description,appointmentid,))
                cur.fetchone()
                con.commit()

            elif choice == "3":
                appointmentdate = input("enter the appointmentdate: ")
                query = "update appointment set appointmentdate=%s where appointmentid= %s"
                cur.execute(query, (appointmentdate,appointmentid,))
                cur.fetchone()
                con.commit()

            else:
                print("invalid choose from above option")
            query = "select * from appointment where appointmentid=%s"
            cur.execute(query,(appointmentid,))
            output = cur.fetchall()
            for i in output:
                print(i)
            con.commit()
        finally:
            con.commit()

    def cancelAppointment(self,appointmentid):
        query="delete from appointment where appointmentid=%s"
        cur.execute(query,(appointmentid,))
        output=cur.fetchall()
        con.commit()
        for i in output:
            print(i)
        print(f"appointment {appointmentid} has canceled successfully")


