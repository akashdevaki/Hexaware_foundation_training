from abstract_method_impl import ihospitalserviceimpl

def main():
    crime=ihospitalserviceimpl()

    while True:
        print("choose the options from given below: ")
        print("1.getAppointmentById: ")
        print("2.get appointment for patient: ")
        print("3.get Appointments For Doctor: ")
        print("4.schedule Appointment: ")
        print("5.update Appointment: ")
        print("6.cancel Appointment: ")
        print("7.exit")
        choice=input("enter the option you have choosen: ")
        if choice=="1":
            appointmentid=input("enter the appointmentid: ")
            crime.getAppointmentById(appointmentid)

        elif choice=="2":
            patienttid = input("enter the patienttid: ")
            crime.getAppointmentsForPatient(patienttid)

        elif choice=="3":
            doctorid = input("enter the doctorid: ")
            crime.getAppointmentsForDoctor(doctorid)
        elif choice=="4":
            crime.scheduleAppointment()
        elif choice=="5":
            print(crime.all_patients())
            appointmentid=input("enter the appointmentid: ")
            crime.updateAppointment(appointmentid)
        elif choice=="6":
            appointmentid = input("enter the appointmentid: ")
            crime.cancelAppointment(appointmentid)
        elif choice=="7":
            print("exiting the system \n Thank you")
            break;
        else:
            print("invalid option choose from above given options")





main()
