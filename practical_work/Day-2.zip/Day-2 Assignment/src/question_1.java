import java.util.*;
	public class question_1
	{
		private static Set<String> dictionary = new HashSet<>();		
		public static void main(String []args)
		{
			String temp_dic[] = { "i", "like", "sam", "sung", "samsung", "mobile", "ice", 
				  "cream", "icecream", "man", "go", "mango"};
 
			for (String temp :temp_dic)
			{
				dictionary.add(temp);
			}

			if(wordBreak("ilike")) {
				System.out.println("Yes");
			}
			else {
				System.out.println("No");
			}
			if(wordBreak("ilikesamsung")) {
				System.out.println("Yes");
			}
			else {
				System.out.println("No");
			}		
		}
		public static boolean wordBreak(String word)
		{
			int size = word.length();

			if (size == 0)
			return true;
			for (int i = 1; i <= size; i++)
			{
				if (dictionary.contains(word.substring(0,i)) && 
						wordBreak(word.substring(i,size)))
				return true;
			}
			return false;
		}
	}




