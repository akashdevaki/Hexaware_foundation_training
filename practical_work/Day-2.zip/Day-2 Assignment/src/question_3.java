
class question_3 
{
	static boolean isDivisibleBy7(int num)
	{
		
		if( num < 0 )
            return isDivisibleBy7( -num );
        if( num == 0 || num == 7 )
            return true;
        if( num < 10 )
            return false;
		return isDivisibleBy7( num / 10 - 2 * ( num - num / 10 * 10 ) );
	}
	public static void main (String[] args) 
	{
		int num = 371;
		int num1=561;
		if(isDivisibleBy7(num))
			System.out.println(num+" is Divisible by 7");
		else
			System.out.println(num+ " is Not Divisible by 7");
		if(isDivisibleBy7(num1))
			System.out.println(num1+" is Divisible by 7");
		else
			System.out.println(num1+ " is Not Divisible by 7");
	}
}



