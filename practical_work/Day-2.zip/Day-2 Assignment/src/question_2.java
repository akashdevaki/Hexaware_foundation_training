

class question_2 {

	static int minCount(int n)
	{
		int[] squreq = new int[n + 1];

		squreq[0] = 0;
		squreq[1] = 1;

		for (int i = 2; i <= n; ++i)
		{
			squreq[i] = Integer.MAX_VALUE;

			for (int j = 1; i - (j * j) >= 0; ++j)

			{

				squreq[i] = Math.min(squreq[i], squreq[i - (j * j)]);
			}

			squreq[i] += 1;
		}
		int ans = squreq[n];
		return ans;
	}
	public static void main(String[] args) {
		System.out.println(minCount(100));
		System.out.println(minCount(6));
		
	}
}


