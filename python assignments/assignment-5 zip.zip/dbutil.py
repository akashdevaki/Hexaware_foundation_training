import mysql.connector
class dbutil:
    @staticmethod
    def dbconn():
        con=mysql.connector.connect(
                    host="localhost",
                    user="root",
                    password="root",
                    port="3306",
                    database="TicketBookingSystem"
                    )
        print(con)
        cur=con.cursor()

if __name__ == "__main__":
    # Create an instance of the DBUtil class
    db_util = dbutil()
    dbutil.dbconn()
