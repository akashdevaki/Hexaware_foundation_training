import functools
from datetime import *
import mysql.connector

from abstract_methods import BookingSystemRepositoryImpl
class EventNotFoundException(Exception):
    pass

class InvalidBookingIDException(Exception):
    pass

con=mysql.connector.connect(
            host="localhost",
            user="root",
            password="root",
            port="3306",
            database="TicketBookingSystem"
            )
cur=con.cursor()


class BookingSystemRepository(BookingSystemRepositoryImpl):

    def create_event(self):
        #event_id=self.generate_unique_event_id()
        event_id=input("enter the id")
        event_name = input("Enter event name: ")
        date=self.get_current_date()
        time=self.get_current_time()
       # venue_id = input("Enter venue id: ")
        total_seats = int(input("Enter total seats: "))
        ticket_price = float(input("Enter ticket price: "))
        event_type = input("Enter event type (movie, sport, concert): ")
        eve1={
            'event_id':event_id,
            'event_name': event_name,
            'event_date':date,
            'event_time':time,
            #'venue-id':venue_id,
            'total_Seats':total_seats,
            'ticket_price':ticket_price,
            'event_type':event_type
        }
        query = "insert into event(event_id,event_name,event_date,event_time,total_seats,ticket_price,event_type)  " \
                "values(%s,%s,%s,%s,%s,%s,%s)"
        values = (eve1['event_id'],eve1['event_name'],eve1['event_date'],eve1['event_time'],
                  eve1['total_Seats'], eve1['ticket_price'],eve1['event_type'])
        cur.execute(query, values)
        cur.execute("select * from event")
        user = cur.fetchall()
        con.commit()
        for i in user:
            print(i)
    def get_current_date(self):
        return date.today()
    def get_current_time(self):
        return datetime.now().time()

    def get_event_details(self):
        return self.all_events()
    def all_events(self):
        query="select * from event"
        cur.execute(query)
        user = cur.fetchall()
        con.commit()
        for i in user:
            print(i)

    def get_avaliable_tickets(self):
        return self.avaliable_tickets()
    def avaliable_tickets(self):

        query="select avaliable_seats,event_name from event"
        cur.execute(query)
        user = cur.fetchall()
        con.commit()
        for i in user:
            print(i)
    '''def booking_cost(self,num_tickets):
        cost=num_tickets*ticket_price'''
    def create_customer(self):
        customer_id=self.unique_customer_id()
        customer_name=input("enter your name")
        email=input("enter your email")
        phone=input("enter your phone number")
        booking_id=self.unique_booking_id()
        cust={
            'customer_id':customer_id,
            'customer_name':customer_name,
            'email':email,
            'phone':phone,
            'booking_id':booking_id
        }
        query="insert into customer values(%s,%s,%s,%s,%s)"
        values=(cust['customer_id'],cust['customer_name'],cust['email'],cust['phone'],cust['booking_id'])
        cur.execute(query,values)
        cur.fetchall()



    def book_tickets(self,num_tickets:int):

        self.get_event_details()

        event_name = (input("enter the event name"))
        try:
            query="select event_name from event where event_name=%s"
            cur.execute(query,(event_name,))
            event=cur.fetchone()
            if not event:
                print(f"Error: {event_name} not found")
                return None
            self.create_customer()

            customer_id = self.unique_customer_id()
            event_id = input("enter the event id")
            num_ticket = num_tickets
            query = "select ticket_price from event where event_id=%s "
            cur.execute(query, (event_id,))
            res = cur.fetchone()
            res = res[0]
            total_cost = int(num_tickets) * res
            booking_date = self.get_current_date()
            booking_id = self.unique_booking_id()

            book = {
                'booking_id': booking_id,
                'customer_id': customer_id,
                'event_id': event_id,
                'num_tickets': num_ticket,
                'total_cost': total_cost,
                'booking_date': booking_date
            }
            sql = "insert into booking values(%s,%s,%s,%s,%s,%s)"
            values = (book['booking_id'], book['customer_id'], book['event_id'],
                      book['num_tickets'], book['total_cost'],book['booking_date'])
            cur.execute(sql, values)
            cur.fetchall()
            sql1="select avaliable_seats from event where event_name= %s"
            cur.execute(sql1,(event_name,))
            results = cur.fetchone()
            results=results[0]
            results=int(results)
            if int(num_tickets) < results:
                results= int(num_tickets)-results
                print(f"Booked {num_tickets} tickets. Available seats: {results}")
            else:
                print("Not enough available seats for the requested number of tickets.")
        finally:
            con.commit()
            con.commit()




    def cancel_tickets(self):
        try:
            avaliable_seats=100
            booking_id=int(input("enter the booking_id"))
            query="select booking_id from booking where booking_id=%s"
            cur.execute(query,(booking_id,))
            book=cur.fetchone()
            if not book:
                print(f"Error {booking_id} not found")
                return None
            sql = "select num_tickets from booking where booking_id=%s "
            cur.execute(sql, (booking_id,))
            num_tickets = cur.fetchone()
            num_tickets = num_tickets[0]
            avaliable_seats += num_tickets
            query="delete from booking where booking_id=%s "
            cur.execute(query,(booking_id,))
            qu = "delete from customer where booking_id=%s "
            cur.execute(qu, (booking_id,))


            print(f"after canceling {num_tickets} the avaliable tickets are {avaliable_seats}")
        finally:
            con.commit()
            con.close()



    def get_booking_details(self):
        return self.booking_details()
    def booking_details(self):
        try:
            booking_id=(input("enter the booking_id"))
            query="select * from booking where booking_id=%s"
            cur.execute(query,(booking_id,))
            user = cur.fetchone()
            user=user[0]
            if not booking_id==user:
                raise InvalidBookingIDException(f"Event '{booking_id}' not found in the menu.")
            con.commit()


        except InvalidBookingIDException as e:
            print(f"Error: {e}")

    def get_all_customers(self):
        query="select * from customer"
        cur.execute(query)
        return cur.fetchall()

    def unique_customer_id(self):
        return len(self.get_all_customers())+1

    def get_all_bookings(self):
        query = "select * from booking"
        cur.execute(query)
        return cur.fetchall()

    def unique_booking_id(self):
        return len(self.get_all_bookings()) + 1

b=BookingSystemRepository()
'''b.create_event()
b.get_event_details()
b.get_avaliable_tickets()
b.book_tickets(5)'''
#b.create_customer()

#print(b.unique_booking_id())

class TicketBookingSystem:
    while True:
        print("1.create Event")
        print("2.book_tickets")
        print("3.cancel tickets")
        print("4.get avaliable tickets")
        print("5.get event details")
        print("6.exit")
        choice=input("select from above options: ")
        if choice=="1":
            b.create_event()
        elif choice=="2":
            num_tickets=input("enter the num_tickets")
            b.book_tickets(num_tickets)
        elif choice=="3":
            b.cancel_tickets()
        elif choice=="4":
            b.get_avaliable_tickets()
        elif choice=="5":
            b.get_event_details()
        elif choice=="6":
            print("exiting the system\n Thank you")
            break;
        else:
            print("invalid option chosen, chose from above options")



query="select * from customer"
cur.execute(query)
user=cur.fetchall()
for i in user:
    print(i)


query1="select * from booking"
cur.execute(query1)
user=cur.fetchall()
for i in user:
    print(i)

























