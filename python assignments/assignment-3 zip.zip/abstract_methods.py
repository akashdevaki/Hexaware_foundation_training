from abc import ABC, abstractmethod

class IBankRepository:
    def create_account(self):
        pass
    def deposit(self):
        pass
    def withdraw(self):
        pass
    def get_account_balance(self):
        pass
    def transfer(self):
        pass
    def get_account_details(self):
        pass
    def get_all_accounts(self):
        pass
    def transaction_details(self):
        pass
