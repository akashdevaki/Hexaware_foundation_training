
credit_score=int(input("enter your credit score"))
annual_income=int(input("enter your annual income"))

'''question 2'''
if(credit_score>700 and annual_income>50000):
    print("you are eligible for the loan")
else:
    print("you are not eligible for the loan")