class Transaction:
    def __init__(self, accountid,transaction_id,transaction_type, amount,transaction_date,):
        self.accountid=accountid,
        self.transaction_id=transaction_id
        self.transaction_type = transaction_type
        self.amount = amount
        self.transaction_Date=transaction_date

    @property
    def getaccountid(self):
        return self.accountid
    @property
    def gettransaction_id(self):
        return self.transaction_id
    @property
    def gettransaction_type(self):
        return self.transaction_type
    @property
    def getamount(self):
        return self.amount
    @property
    def gettransaction_date(self):
        return self.transaction_date

    @getaccountid.setter
    def setaccountid(self,accountid):
        self.accountid=accountid
    @gettransaction_id.setter
    def settransaction_id(self,transaction_id):
        self.transaction_id=transaction_id
    @gettransaction_type.setter
    def settransaction_type(self,transaction_type):
        self.transaction_type=transaction_type
    @getamount.setter
    def setamount(self,amount):
        self.amount=amount
    @gettransaction_date.setter
    def settransaction_date(self,transaction_date):
        self.transaction_date=transaction_date


    def display_transaction(self):
        print(f"{self.transaction_type}: ${self.amount}")


class BankTransactionManager:
    def __init__(self):
        self.transactions = []

    def add_transaction(self, transaction_type, amount):
        new_transaction = Transaction(transaction_type, amount)
        self.transactions.append(new_transaction)
        print(f"Transaction added: {transaction_type}: ${amount}")

    def display_transaction_history(self):
        print("\nTransaction History:")
        for transaction in self.transactions:
            transaction.display_transaction()


def main():
    bank_manager = BankTransactionManager()

    while True:
        print("\n1. Add Deposit\n2. Add Withdrawal\n3. Display Transaction History\n4. Exit")
        choice = input("Enter your choice (1-4): ")

        if choice == '1':
            amount = float(input("Enter deposit amount: "))
            bank_manager.add_transaction("Deposit", amount)

        elif choice == '2':
            amount = float(input("Enter withdrawal amount: "))
            bank_manager.add_transaction("Withdrawal", amount)

        elif choice == '3':
            bank_manager.display_transaction_history()

        elif choice == '4':
            print("Exiting the program. Displaying final transaction history:")
            bank_manager.display_transaction_history()
            break

        else:
            print("Invalid choice. Please enter a number between 1 and 4.")


if __name__ == "__main__":
    main()
