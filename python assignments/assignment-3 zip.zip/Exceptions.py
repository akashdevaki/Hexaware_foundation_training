class Accountidnotfound:
    pass