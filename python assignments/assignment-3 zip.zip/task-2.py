class ATM:
    def __init__(self):
        self.balance = 0

    def display_options(self):
        print("1. Check Balance")
        print("2. Withdraw")
        print("3. Deposit")
        print("4. Quit")

    def check_balance(self):
        print(f"Your current balance is: ${self.balance}")

    def withdraw(self, amount):
        if amount <= 0:
            print("Invalid withdrawal amount. Please enter a valid amount.")
        elif amount % 100 != 0 and amount % 500 != 0:
            print("Withdrawal amount must be in multiples of 100 or 500.")
        elif amount > self.balance:
            print("Insufficient funds. Cannot withdraw.")
        else:
            self.balance -= amount
            print(f"Withdrawal successful. Remaining balance: ${self.balance}")

    def deposit(self, amount):
        if amount <= 0:
            print("Invalid deposit amount. Please enter a valid amount.")
        else:
            self.balance += amount
            print(f"Deposit successful. New balance: ${self.balance}")

def main():
    atm = ATM()

    while True:
        atm.display_options()
        choice = input("Enter your choice (1-4): ")

        if choice == "1":
            atm.check_balance()
        elif choice == "2":
            amount = int(input("Enter the amount to withdraw: $"))
            atm.withdraw(amount)
        elif choice == "3":
            amount = int(input("Enter the amount to deposit: $"))
            atm.deposit(amount)
        elif choice == "4":
            print("Thank you for using the ATM. Goodbye!")
            break
        else:
            print("Invalid choice. Please enter a number between 1 and 4.")
        break

if __name__ == "__main__":
    main()
