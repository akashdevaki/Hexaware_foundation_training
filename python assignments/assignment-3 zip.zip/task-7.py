import mysql.connector

class Customer:
    def __init__(self, customer_id, first_name, last_name, email, phone_number, address):
        self._customer_id = customer_id
        self._first_name = first_name
        self._last_name = last_name
        self._email = email
        self._phone_number = phone_number
        self._address = address

    @property
    def get_customer_id(self):
        return self._customer_id
    @get_customer_id.setter
    def set_customer_id(self,customer_id):
        self._customer_id=customer_id


    @property
    def get_first_name(self):
        return self._first_name
    @get_first_name.setter
    def set_first_name(self,first_name):
        self._first_name=first_name

    @property
    def get_last_name(self):
        return self._last_name

    @get_last_name.setter
    def set_last_name(self,last_name):
        self._last_name=last_name

    @property
    def get_email(self):
        return self._email
    @get_email.setter
    def set_email(self,email):
        self._email=email

    @property
    def get_phone_number(self):
        return self._phone_number
    @get_phone_number.setter
    def set_phone_number(self,phone_number):
        self._phone_number=phone_number

    @property
    def get_address(self):
        return self._address
    @get_address.setter
    def set_address(self,address):
        self._address=address



    def print_customer_info(self):
        print("Customer ID:", self._customer_id)
        print("First Name:", self._first_name)
        print("Last Name:", self._last_name)
        print("Email Address:", self._email)
        print("Phone Number:", self._phone_number)
        print("Address:", self._address)

# Example usage:
'''customer1 = Customer("123456", "John", "Doe", "john.doe@example.com", "555-1234", "123 Main St")
customer1.set_customer_id=123456
print("Customer ID:", customer1.get_customer_id())
print("First Name:", customer1.get_first_name())
print("Last Name:", customer1.get_last_name())
print("Email Address:", customer1.get_email())
print("Phone Number:", customer1.get_phone_number())
print("Address:", customer1.get_address())'''



customer1 = Customer("123456", "John", "Doe", "john.doe@example.com", "555-1234", "123 Main St")
customer1.print_customer_info()



class Account:
    def __init__(self, account_number=None, account_type=None, account_balance=None):
        self._account_number = account_number
        self._account_type = account_type
        self._account_balance = account_balance

    # Getter methods
    @property
    def get_account_number(self):
        return self._account_number

    @property
    def get_account_type(self):
        return self._account_type

    @property
    def get_account_balance(self):
        return self._account_balance

    # Setter methods
    @get_account_number.setter
    def set_account_number(self, account_number):
        self._account_number = account_number
    @get_account_type.setter
    def set_account_type(self, account_type):
        self._account_type = account_type
    @get_account_balance.setter
    def set_account_balance(self, account_balance):
        self._account_balance = account_balance

    # Method to print all information
    def print_account_info(self):
        print("Account Number:", self._account_number)
        print("Account Type:", self._account_type)
        print("Account Balance:", self._account_balance)

    # Deposit method
    def deposit(self, amount):
        self._account_balance += amount
        print(f"Deposited {amount} into the account. New balance: {self._account_balance}")

    # Withdraw method
    def withdraw(self, amount):
        if amount <= self._account_balance:
            self._account_balance -= amount
            print(f"Withdrew {amount} from the account. New balance: {self._account_balance}")
        else:
            print("Insufficient balance. Withdrawal not allowed.")

    # Calculate interest method
    def calculate_interest(self):
        interest_rate = 0.045  # 4.5%
        interest_amount = self._account_balance * interest_rate
        self._account_balance += interest_amount
        print(f"Interest calculated and added. New balance: {self._account_balance}")


class Bank:
    def operate_account(self):
        # Create an object for the Account class by calling the parameter constructor
        account1 = Account("123456", "Savings", 1000.0)

        # Deposit into the account
        account1.deposit(500.0)

        # Withdraw from the account
        account1.withdraw(200.0)

        # Calculate interest for savings account
        if account1.get_account_type().lower() == "savings":
            account1.calculate_interest()

        # Print final account information
        account1.print_account_info()


# Example usage:
bank = Bank()
bank.operate_account()


# Task-8
'''class Account:
    def __init__(self, account_number=None, account_type=None, account_balance=None):
        self._account_number = account_number
        self._account_type = account_type
        self._account_balance = account_balance

    # Other methods (getters, setters, print_account_info) remain unchanged

    # Overloaded deposit method for float
    def deposit(self, amount: float):
        self._account_balance += amount
        print(f"Deposited {amount} into the account. New balance: {self._account_balance}")

    # Overloaded withdraw method for float
    def withdraw(self, amount: float):
        if amount <= self._account_balance:
            self._account_balance -= amount
            print(f"Withdrew {amount} from the account. New balance: {self._account_balance}")
        else:
            print("Insufficient balance. Withdrawal not allowed.")

    # Overloaded deposit method for int
    def deposit(self, amount: int):
        self._account_balance += amount
        print(f"Deposited {amount} into the account. New balance: {self._account_balance}")

    # Overloaded withdraw method for int
    def withdraw(self, amount: int):
        if amount <= self._account_balance:
            self._account_balance -= amount
            print(f"Withdrew {amount} from the account. New balance: {self._account_balance}")
        else:
            print("Insufficient balance. Withdrawal not allowed.")

    # Overloaded deposit method for double
    def deposit(self, amount: float):
        self._account_balance += amount
        print(f"Deposited {amount} into the account. New balance: {self._account_balance}")

    # Overloaded withdraw method for double
    def withdraw(self, amount: float):
        if amount <= self._account_balance:
            self._account_balance -= amount
            print(f"Withdrew {amount} from the account. New balance: {self._account_balance}")
        else:
            print("Insufficient balance. Withdrawal not allowed.")

# Example usage:
account = Account("123456", "Savings", 1000.0)
account.deposit(500.0)
account.withdraw(200.0)
account.deposit(300)  # Now it uses the int overload
account.withdraw(150)  # Now it uses the int overload
account.deposit(400.0)  # Now it uses the float overload
account.withdraw(250.0)  # Now it uses the float overload
'''

######

class SavingsAccount(Account):
    def __init__(self, account_number, account_holder, balance, interest_rate):
        super().__init__(account_number, account_holder, balance)
        self.interest_rate = interest_rate

    def calculate_interest(self):
        interest = self.balance * (self.interest_rate / 100)
        print(f"Interest calculated: ${interest}")
        self.balance += interest


class CurrentAccount(Account):
    OVERDRAFT_LIMIT = 1000  # Example overdraft limit

    def __init__(self, account_number, account_holder, balance):
        super().__init__(account_number, account_holder, balance)

    def withdraw(self, amount):
        available_balance = self.balance + self.OVERDRAFT_LIMIT
        if amount <= available_balance:
            self.balance -= amount
            print(f"${amount} withdrawn. New balance: ${self.balance}")
        else:
            print("Exceeds overdraft limit. Transaction canceled.")


# Example usage
'''savings_account = SavingsAccount("SA123", "John Doe", 5000, 2.5)
current_account = CurrentAccount("CA456", "Jane Doe", 2000)


savings_account.calculate_interest()


current_account.display_account_details()
current_account.withdraw(2500)
current_account.display_account_details()'''

####



class Bank:
    def create(self):
        while True:
            print("\n1. Create Savings Account\n2. Create Current Account\n3. Exit")
            choice = input("Enter your choice (1-3): ")

            if choice == '1':
                account_number = input("Enter account number: ")
                account_holder = input("Enter account holder name: ")
                balance = float(input("Enter initial balance: "))
                interest_rate = float(input("Enter interest rate for savings account: "))

                account = SavingsAccount(account_number, account_holder, balance, interest_rate)
                print("Savings Account created successfully!")

            elif choice == '2':
                account_number = input("Enter account number: ")
                account_holder = input("Enter account holder name: ")
                balance = float(input("Enter initial balance: "))

                account = CurrentAccount(account_number, account_holder, balance)
                print("Current Account created successfully!")

            elif choice == '3':
                print("Exiting the Bank System.")
                break

            else:
                print("Invalid choice. Please enter a number between 1 and 3.")

            while True:
                print("\n1. Deposit\n2. Withdraw\n3. Calculate Interest (Savings Account)\n4. Display Account Details\n5. Back to Main Menu")
                operation = input("Enter operation choice (1-5): ")

                if operation == '1':
                    amount = float(input("Enter deposit amount: "))
                    account.deposit(amount)

                elif operation == '2':
                    amount = float(input("Enter withdrawal amount: "))
                    account.withdraw(amount)

                elif operation == '3' and isinstance(account, SavingsAccount):
                    account.calculate_interest()

                elif operation == '4':
                    account.display_account_details()

                elif operation == '5':
                    break

                else:
                    print("Invalid choice. Please enter a number between 1 and 5.")


# Example usage
'''bank_system = Bank()
bank_system.create()'''

#####   Task 12
class InsufficientFundException(Exception):
    pass

class InvalidAccountException(Exception):
    pass

class OverDraftLimitExceededException(Exception):
    pass

class HMBank:
    def __init__(self, account_balance, overdraft_limit):
        self.account_balance = account_balance
        self.overdraft_limit = overdraft_limit

    def withdraw(self, amount):
        if amount > self.account_balance:
            raise InsufficientFundException("Insufficient funds in the account.")
        self.account_balance -= amount

    def transfer(self, amount, target_account):
        if amount > self.account_balance:
            raise InsufficientFundException("Insufficient funds in the account.")
        if not target_account.is_valid():
            raise InvalidAccountException("Invalid account number.")
        target_account.deposit(amount)
        self.account_balance -= amount

    def withdraw_from_current_account(self, amount):
        if amount > self.account_balance + self.overdraft_limit:
            raise OverDraftLimitExceededException("Withdrawal exceeds overdraft limit.")
        self.account_balance -= amount


class BankAccount:
    def __init__(self, account_number, is_valid=True):
        self.account_number = account_number
        self.is_valid = is_valid

    def is_valid(self):
        return self.is_valid

    def deposit(self, amount):
        # Perform deposit operation
        pass


def main():
    try:
        # Example usage
        savings_account = HMBank(1000, 0)
        current_account = HMBank(500, 1000)

        target_account = BankAccount("123456789", True)

        savings_account.withdraw(200)
        savings_account.transfer(300, target_account)
        current_account.withdraw_from_current_account(700)

    except InsufficientFundException as e:
        print(f"Error: {e}")

    except InvalidAccountException as e:
        print(f"Error: {e}")

    except OverDraftLimitExceededException as e:
        print(f"Error: {e}")

    except Exception as e:
        print(f"Unexpected error: {e}")



if __name__ == "__main__":
    main()


