import random

import mysql.connector
from unicodedata import decimal
from abstract_methods import IBankRepository
con=mysql.connector.connect(
	host="localhost",
	user="root",
	password="root",
	port="3306",
    database="HMBank"
	)
print(con)
cur=con.cursor()
class IBankRepositoryimpl(IBankRepository):
	def create_customer(self):
		customerid=input("enter the customer id")
		firstname=input("enter your first name")
		lastname = input("enter your last name")
		dateofbirth=input("enter your date of birth")
		email = input("enter your email")
		phonenumber = input("enter your phonenumber")
		address = input("enter your address")
		cus={
			'customerid':customerid,
			'firstname':firstname,
			'lastname':lastname,
			'dateofbirth':dateofbirth,
			'email':email,
			'phonenumber':phonenumber,
			'address':address
		}
		sql="insert into customers values(%s,%s,%s,%s,%s,%s,%s)"
		values=(cus['customerid'],cus['firstname'],cus['lastname'],cus['dateofbirth'],
				cus['email'],cus['phonenumber'],cus['address'])
		cur.execute(sql,values)
		user=cur.fetchall()
		for i in user:
			print(i)

	def get_all_customer(self):
		query="select * from customers"
		cur.execute(query)
		return cur.fetchall()
	def unique_customer_id(self):
		return len(self.get_all_customer())+1


	def create_account(self):
		print("enter your details: ")
		self.create_customer()
		accountid=random.randint(110,150)
		customerid=input("enter the customer id")
		accounttype=input("select the account (savings,current)")
		balance=input("enter the balance")
		acc={'accountid':accountid,
			 'customerid':customerid,
			 'accounttype':accounttype,
			 'balance':balance
			 }
		query="insert into account (accountid,customerid,accounttype,balance) values(%s,%s,%s,%S)"
		values=(acc['accountid'],acc['customerid'],acc['accounttype'],acc['balance'])
		cur.execute(query,values)
		cur.execute("select * from accounts")
		user=cur.fetchall()
		con.commit()
		for i in user:
			print(i)


	def get_all_accounts(self):
		sql="select * from accounts"
		cur.execute(sql)
		user = cur.fetchall()
		for i in user:
			print(i)

	def get_account_balance(self):
		accountid=input("enter the accountid")
		sql="select balance from accounts where accountid=%s"
		cur.execute(sql,(accountid,))
		print(cur.fetchall())

	def get_account_details(self):
		customerid=input("enter the customerid")
		sql="select c.*,a.* from customers c join accounts a on c.customerid=a.customerid where c.customerid=%s;"
		cur.execute(sql, (customerid,))
		user=cur.fetchall()
		for i in user:
			print(i)
	def transaction_details(self):
		accountid=input("enter the account number")
		startdate=input("enter the startdate")
		enddate=input("enter the enddate")
		sql="select * from transactions where accountid=%s and transaction_date between %s and %s"
		cur.execute(sql, (accountid,startdate,enddate))
		user = cur.fetchall()
		for i in user:
			print(i)


	def deposit(self):
		accountid=input("enter the accout id")
		amount=int(input("Enter the amount to deposit"))
		try:
			cur.execute("SELECT balance FROM accounts WHERE accountid = %s", (accountid,))
			current_balance = cur.fetchone()
			if not current_balance:
				print(f"Error: Account {accountid} not found.")
				return None
			current_balance = current_balance[0]
			new_balance = current_balance + amount
			cur.execute( 'UPDATE accounts SET balance = %s WHERE accountid = %s ', (new_balance, accountid))
			con.commit()
			print(f"Deposit successful. New balance: {new_balance}")
			return new_balance
		finally:
			cur.close()
			con.close()




	def withdraw(self):

		accountid=input("enter the account id")
		amount=int(input("enter the amount to withdraw"))
		try:
			cur.execute("SELECT balance, accounttype FROM accounts WHERE accountid = %s", (accountid,))
			account_details = cur.fetchone()
			if not account_details:
				print(f"Error: Account {accountid} not found.")
				return None
			current_balance, accounttype = account_details
			if accounttype == 'savings' and (current_balance - amount) < 500:
				print("Error: Withdrawal violates minimum balance rule for savings account.")
				return None
			elif accounttype == 'current' and amount > (current_balance + 1000):
				print("Error: Withdrawal exceeds available balance and overdraft limit for current account.")
				return None
			new_balance = current_balance - amount
			cur.execute("UPDATE accounts SET balance = %s WHERE accountid = %s" , (new_balance, accountid))
			con.commit()
			print(f"Withdrawal successful. New balance: {new_balance}")
			return new_balance
		finally:
			cur.close()
			con.close()

	def transfer(self):
		fromaccountid = input("enter the from account number")
		toaccountid = input("enter the to account number")
		amount = int(input("enter the amount to transfer"))
		try:
			cur.execute("SELECT balance FROM accounts WHERE accountid = %s", (fromaccountid,))
			from_account_balance = cur.fetchone()
			if not from_account_balance:
				print(f"Error: Account {fromaccountid} not found.")
				return False
			from_account_balance = from_account_balance[0]
			if from_account_balance < amount:
				print("Error: Insufficient funds for transfer.")
				return False
			new_from_balance = from_account_balance - amount
			cur.execute("UPDATE accounts SET balance = %s WHERE accountid = %s", (new_from_balance, fromaccountid))
			cur.execute("SELECT balance FROM accounts WHERE accountid = %s", (toaccountid,))
			to_account_balance = cur.fetchone()
			if not to_account_balance:
				print(f"Error: Account {toaccountid} not found.")
				return False
			to_account_balance = to_account_balance[0]
			new_to_balance = to_account_balance + amount
			cur.execute("UPDATE accounts SET balance = %s WHERE accountid = %s", (new_to_balance, toaccountid))
			con.commit()
			print("Transfer successful.")
			return True
		finally:
			cur.close()
			con.close()
		transfer_successful = transfer(fromaccountid, toaccountid, transfer_amount)
		if transfer_successful:
			print("Transfer was successful.")
		else:
			print("Transfer failed.")


	def calculateInterest(self):
		interest_rate=0.045
		accountid=input("enter the accountid")
		try:
			# Fetch account details including balance and interest rate
			cur.execute("SELECT accountid, balance FROM accounts where accountid=%s",(accountid,))

			accounts_data = cur.fetchall()

			for account in accounts_data:
				accountid, balance = account
				interest = (float(balance) * interest_rate) / 100
				print(f"Account {accountid}: Interest calculated - {interest}")
			print("Interest calculation completed.")
		finally:
			cur.close()
			con.close()

bank=IBankRepositoryimpl()
'''bank.get_all_accounts()'''
bank.calculateInterest()
#print(bank.unique_customer_id())

'''class bankapp:
	while True:
		print("1.create_account")
		print("2.deposit")
		print("3.withdraw")
		print("4.get_balance")
		print("5.transfer")
		print("6.getAccountDetails")
		print("7.ListAccounts")
		print("8.getTransactions")
		print("9.exit")
		choice = input("select from above options: ")
		if choice == "1":
			bank.create_account()

		elif choice=="2":
			bank.deposit()

		elif choice=="3":
			bank.withdraw()

		elif choice=="4":
			bank.get_account_balance()
		elif choice=="5":
			bank.transfer()

		elif choice=="6":
			bank.get_account_details()
		elif choice=="7":
			bank.get_all_accounts()
		elif choice=="8":
			bank.transaction_details()
		elif choice=="9":
			print("you are going to exit\n Thank you")
			break;
		else:
			print("invalid option choosen.please select from above")'''


