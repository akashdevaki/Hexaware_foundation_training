'''account=56789
while True:
    account_number=int(input("enter the account number"))
    if(account_number!=account):
        print("enter the correct account number")
    else:

        print("account balance")
        break
'''














class Bank:
    def __init__(self):
        self.accounts = {
            '123456': 1000.0,
            '987654': 1500.0,
            '567890': 500.0
        }

    def validate_account_number(self, acc_number):
        return acc_number in self.accounts

    def display_balance(self, acc_number):
        print(f"Account Number: {acc_number}")
        print(f"Current Balance: ${self.accounts[acc_number]:.2f}")
def main():
    bank = Bank()
    while True:
        acc_number = input("Enter your account number: ")
        if bank.validate_account_number(acc_number):
            # Display the account balance
            bank.display_balance(acc_number)
            break
        else:
            print("Invalid account number. Please try again.")
if __name__ == "__main__":
    main()
