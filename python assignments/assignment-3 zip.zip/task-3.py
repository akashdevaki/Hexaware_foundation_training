mem=int(input("enter the no.of users"))
if mem<=0 :
    print("enter the valid number ")
else:
    for i in range(mem):
        future_balance=0
        initial_balance=int(input("enter the balance "))

        annual_interest_rate=int(input("enter the interest rate: "))
        number_of_years=int(input("number of years: "))
        future_balance = int(initial_balance * (1 + annual_interest_rate / 100) ** number_of_years)
        print("future balance of ",i+1," is: ",future_balance)



